<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Page </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="assets/adminmanagement.css" rel="stylesheet" type="text/css" /> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<!-- hieu ung load -->
<body onLoad="init()">
<div id="loading" style="position:absolute; width:100%; text-align:center; top:250px;">
 
Loading...<br />
 
<img src="loading.gif" border=0></div>
 
<script>
 
var ld=(document.all);
 
var ns4=document.layers;
 
var ns6=document.getElementById&&!document.all;
 
var ie4=document.all;
 
if (ns4)
 
ld=document.loading;
 
else if (ns6)
 
ld=document.getElementById("loading").style;
 
else if (ie4)
 
ld=document.all.loading.style;
 
function init()
 
{
 
if(ns4){ld.visibility="hidden";}
 
else if (ns6||ie4) ld.display="none";
 
}
 
</script>
<!-- HEADER BEGIN -->
	<div class="top-main">
		<div class="wrap">
			<div class="logo">
				<h1>
				
				    <img src="assets/images/logoheader.png">
			
				</h1>
			</div>
		</div>
	</div>
	<!-- HEADER END -->
    <div style="border-top: 10px solid #f29f36;">

<div class="container.fluid">
	<div id="container" > 
  	<h1>Admin Page</h1>
  
  <!-- nut them -->
  	<button type="button" class="btn btn-success btn-lg" data-toggle="modal" data-target="#addform"><span class="glyphicon glyphicon-plus"></span> Thêm </button>

	<!-- Modal -->
	<div id="addform" class="modal fade" role="dialog">
  		<div class="modal-dialog">

    	<!-- Modal content-->
    		<div class="modal-content">
      			<div class="modal-header">
        			<h4 class="modal-title">Thêm </h4>
      			</div>
     		 <div class="modal-body">
      		<!-- form -->
        	<form name="forminsert" action="adminmanagement.php" method="post"onsubmit="return checkInput();">
 			 <div class="form-group">
    		<label >Mã đồ án:</label>
   			 <input type="text" class="form-control"  name="madoan">
 			 </div>
             <div class="form-group">
    		<label >Tên đồ án:</label>
   			 <input type="text" class="form-control"  name="detai">
 			 </div>
 			 <div class="form-group">
   			 <label ">Tác giả</label>
   			<input type="text" class="form-control"  name="tacgia">
 			 </div>
             <div class="form-group">
    		<label >Giáo viên hướng dẫn</label>
   			 <input type="text" class="form-control"name="giaovienhuongdan">
 			 </div>
 			 <div class="form-group">
   			 <label >Giáo viên phản biện</label>
   			<input type="text" class="form-control"  name="giaovienphanbien">
 			 </div>
			  <div class="form-group">
   			 <label >Link File</label>
   			<input type="text" class="form-control"  name="linkfile">
 			 </div>
			
     		 </div>
    		  <!--end form -->
      <div class="modal-footer">
      <input type="submit" class="btn btn-success" value="Save" /> 
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </form>
      </div>
    </div>



  </div>
</div>

<!-- xu ly them -->
<?php
	 require 'configs/db.php';
	 if(isset($_POST['madoan']))
	 {
	$madoan = $_POST["madoan"]; 
 	$detai = $_POST["detai"];
	$tacgia = $_POST["tacgia"];
	$giaovienhuongdan = $_POST["giaovienhuongdan"];
	$giaovienphanbien = $_POST["giaovienphanbien"];
	$linkfile = $_POST["linkfile"];
	 
	$sql="insert into DOAN(maDoAn,deTai,tacGia,giaoVienHuongDan,giaoVienPhanBien,linkFile) "; 
$sql .=" values('".$madoan."','".$detai."','".$tacgia."','".$giaovienhuongdan."','".$giaovienphanbien."','".$linkfile."')"; 
$result = mysql_query($sql,$link); if($result) 
$affectrow = mysql_affected_rows();
 mysql_close($link);
	 }
?>
<!-- xu ly select *-->
<?php 
require 'configs/db.php';
$totalRows = 0;
$stSQL ="select * from DOAN";
$result = mysql_query($stSQL,$link);
$totalRows = mysql_num_rows($result);
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
        $limit = 10;
$total_page = ceil($totalRows / $limit);
 if ($current_page > $total_page){
            $current_page = $total_page;
        }
        else if ($current_page < 1){
            $current_page = 1;
        }
		
$start = ($current_page - 1) * $limit;

$result = mysql_query("SELECT * FROM doan LIMIT $start, $limit",$link);

?>
<h3>Tổng số đồ án tìm thấy: <?= $totalRows ?></h3>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Mã đồ án</th>
		<th>Đề tài</th>
        <th>Tác giả</th>
        <th>GV Hướng dẫn </th>
		<th>GV Phản biện </th>
		<th>Link File </th>
		<th>Action</th>
      </tr>
    </thead>
	<?php 
	if($totalRows>0){
$i=0;
while ($row = mysql_fetch_array ($result))
{
$i+=1;
?>
    <tbody>
      <tr>
        <td><?=$row["maDoAn"]?></td>
        <td><?=$row["deTai"]?></td>
        <td><?=$row["tacGia"]?></td>
		<td><?=$row["giaoVienHuongDan"]?></td>
		<td><?=$row["giaoVienPhanBien"]?></td>
		<td><?=$row["linkFile"]?></td>
		
	<form action="delete.php" method="post" >
<td><button name="deleteItem" value="<?=$row["maDoAn"]?>" type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-floppy-remove"></span></button>
		</form>
		
		<a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><button type="button" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span></button></a> </td>
		
      </tr>
	<tr>
        <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit,
       </div>
	</tr>
      
    </tbody>
	
	</div>
<?php
 }
}else{
?>
<tr valign="top">
<td >&nbsp;</td>
<td > <b><font face="Arial" color="#FF0000">
Không tìm thấy thông tin môn học!</font></b></td>
</tr>
<?php
}
?>
  </table>
</div>
<center>
	<div class="pagination">
		
		<ul class="pagination">
           <?php 
            // PH?N HI?N TH? PHÂN TRANG
            // BU?C 7: HI?N TH? PHÂN TRANG
	
            // n?u current_page > 1 và total_page > 1 m?i hi?n th? nút prev
            if ($current_page > 1 && $total_page > 1){
                echo '<li><a href="adminmanagement.php?page='.($current_page-1).'">Prev</a></li>  ';
            }
 
            // L?p kho?ng gi?a
            for ($i = 1; $i <= $total_page; $i++){
                // N?u là trang hi?n t?i thì hi?n th? th? span
                // ngu?c l?i hi?n th? th? a
                if ($i == $current_page){
                    echo '<li><span>'.$i.'</span></li> ';
                }
                else{
                    echo '<li><a href="adminmanagement.php?page='.$i.'">'.$i.'</a></li>  ';
                }
            }
 
            // n?u current_page < $total_page và total_page > 1 m?i hi?n th? nút prev
            if ($current_page < $total_page && $total_page > 1){
                echo '<li><a href="adminmanagement.php?page='.($current_page+1).'">Next</a></li>  ';
            }
           ?>
		   </ul>
        </div>
	</div> 
</center>
</div>

<!-- FOOTER BEGIN -->
	<div class="footer-main">
		
	</div>
	<!-- FOOTER END -->
	
</body>

</html>
