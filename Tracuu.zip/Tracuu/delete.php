<?php
 require 'configs/db.php';
if(isset($_POST['deleteItem']) and is_numeric($_POST['deleteItem']))
{
 $sql="DELETE FROM doan WHERE (maDoAn='".$_POST['deleteItem']."')"; 
 
$result = mysql_query($sql,$link);
 if($result) 
 {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: ";
}
mysql_close($link); 
} 
header("Location: http://localhost:8080/Tracuu/adminmanagement.php");
die();
?>