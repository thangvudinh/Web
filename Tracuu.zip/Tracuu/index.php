<!DOCTYPE html>
<html>
<head>
	<title>HỆ THỐNG QUẢN LÝ ĐỒ ÁN 3TK </title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	    <link rel="stylesheet" href="assets/login.css" />
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script type="text/javascript" src="assets/login.js"></script>
</head>
<body>
<div class="page-wrap">
   
	<!-- HEADER BEGIN -->
	<div class="top-main">
		<div class="wrap">
			<div class="logo">
				<h1>
				
				    <img src="assets/images/logoheader.png">
			
				</h1>
			</div>
		</div>
	</div>
	<!-- HEADER END -->
    <div style="border-top: 10px solid #f29f36;">
<div id="formlogin" >
	
		<a href="#login-box" class="login-window button">Đăng nhập</a>
        <div id="login-box" class="login">
            <p class="login_title"> Đăng nhập</p>
            <a href="#" class="close"><img src="assets/images/close.png" class="img-close" title="Close Window" alt="Close" /></a>
            <form method="post" class="login-content" action="#">
            <label class="username">
            <span>Tên</span>
            <input id="username" name="username" value="" type="text" autocomplete="on" placeholder="Username">
            </label>
            <label class="password">
            <span>Mật khẩu</span>
            <input id="password" name="password" value="" type="password" placeholder="Password">
            </label>
            <button class="button submit-button" type="button">Đăng nhập</button>
             
            </form>
        </div>
	</div>
	</div>

	<?php
		$avaiable = isset($_POST['sbd']); 
		$captcha_array = array('w2OO', 'kCT1', '89HT', '2AGT', 'VQl4', 'JC0k', 'PgEt', 'tmI5');
		$captcha_index = rand() % count($captcha_array);
		$captcha_path = "assets/images/captcha/".$captcha_index.".jpg";
	?>

	<!-- FORM BEGIN -->
	
	<div class="container">
	
		<form action="" method="post">
			<h2 style="text-align: center; margin: 30px auto 0px;">TRA CỨU ĐỒ ÁN</h2>
			<div class="wrap2">				
				<p>Thí sinh nhập <b>mã đồ án </b> và <b>mã xác nhận</b> vào các ô dưới đây:</p>
				<!-- <div class="form-group">
					<label><b>Mã xét tuyển</b></label>
					<div class="form-sbd">
						<input type="text" name="mxt" maxlength="12" value="<?php if($avaiable){echo $_POST['sbd'];} else {echo "";}?>">
					</div>
				</div> -->
                <br/>
                <div class="form-group">
                    <label><b>Mã đồ án</b></label>
                    <div class="form-sbd">
                        <input type="text" name="sbd" maxlength="12" value="<?php if($avaiable){echo $_POST['sbd'];} else {echo "";}?>">
                    </div>
                </div>
				<br/>
				<div class="form-group1">
					<label><b>Mã xác nhận</b></label>
					<div class="form-mxn">
						<input id="6_letters_code" name="6_letters_code" type="text"/>
						<!-- <img src="captcha/captcha_code_file.php?rand=<?php echo rand(); ?>" id='captchaimg' ><br> -->	
						<img src="<?php echo $captcha_path; ?>" id='captchaimg' ><br>	
						<small>Tạo mã xác nhận mới <a href='javascript: refreshCaptcha();' style="text-decoration: underline;">tại đây</a></small>
					</div>
				</div>
				<br/>
				<div class="form-group2">
					<input type="submit" name="submit" value="Tra cứu">
				</div>
			</div>
		</form>	
	<!-- FORM END -->
		<script language='JavaScript' type='text/javascript'>
		function refreshCaptcha()
		{
			var img = document.images['captchaimg'];
			//img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
			img.src = "assets/images/captcha/" + Math.floor(Math.random() *1000 % 8) + ".jpg";
		}
		</script>

		<?php 
			$captchavalid = false;
			if(isset($_POST['submit']) && isset($_POST['6_letters_code'])) {
                if (!in_array($_POST['6_letters_code'], $captcha_array)) {
                    echo "
						<div class=\"wrap2\">
						<div align=\"center\">Mã xác nhận không đúng! </div>
						</div>
					";
                } else {
                    $captchavalid = true;
                }
            }

            if($avaiable && $captchavalid){
                require 'configs/config.db.php';
                $stmt = $db->prepare("SELECT * FROM `tracuugx` WHERE `SBD` = :sbd OR `MXT` = :mxt");
                $stmt->execute(array('sbd' => $_POST["sbd"], 'mxt' => $_POST["sbd"]));
                if($stmt->rowCount() > 0) {
                    foreach ($stmt as $row) {
                        ?>
                        <div class="wrap2">
                            <div style="padding-top: 40px; width: 100%;">
                                <div style="margin-left: 5px; line-height: 2;">
                                    <b>Họ tên: </b> <?php echo $row['HOTEN'];?> <br/>

                                    <b>Ngày sinh: </b><?php echo $row['NGAYSINH'];?> <br/>                                   
                                </div>
                                
                            </div>
                            <div >
                                <div>
                                    <div class="nguyenvong-item">
                                        <div class="title">
                                            <label>Nguyện vọng 1</label>
                                        </div>
                                        <div class="noidung">
                                            <?php
                                            $trungtuyen = false;
                                            if($row['NV1-TRUONG'] != NULL) {
                                                ?>
                                                <table>
                                                    <thead><b>Mã trường:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV1-TRUONG'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Mã ngành/nhóm ngành:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV1-NGANH'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Kết quả:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php
                                                    $chucmung = false;
                                                    if($trungtuyen == false) {
                                                        if($row['NV1-KQ'] == 'KO'){
                                                            echo "Không đạt";
                                                        } else {
                                                            $chucmung = true;
                                                            $trungtuyen = true;
                                                            echo "<span style=\"color: blue; font-weight: bold\"> Trúng tuyển</span>";
                                                        }
                                                    }
                                                    ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="nguyenvong-item">
                                        <div class="title">
                                            <label>Nguyện vọng 2</label>
                                        </div>
                                        <div class="noidung">
                                            <?php
                                            if($row['NV2-TRUONG'] != NULL) {
                                                ?>
                                                <table>
                                                    <thead><b>Mã trường:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV2-TRUONG'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Mã ngành/nhóm ngành:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV2-NGANH'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Kết quả:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php
                                                    if($trungtuyen == false) {
                                                        if($row['NV2-KQ'] == 'KO'){
                                                            echo "Không đạt";
                                                        } else {
                                                            $chucmung = true;
                                                            $trungtuyen = true;
                                                            echo "<span style=\"color: blue; font-weight: bold\"> Trúng tuyển</span>";
                                                        }
                                                    }
                                                    ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="nguyenvong-item">
                                        <div class="title">
                                            <label>Nguyện vọng 3</label>
                                        </div>
                                        <div class="noidung">
                                            <?php
                                            if($row['NV3-TRUONG'] != NULL) {
                                                ?>
                                                <table>
                                                    <thead><b>Mã trường:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV3-TRUONG'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Mã ngành/nhóm ngành:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV3-NGANH'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Kết quả:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php
                                                    if($trungtuyen == false) {
                                                        if($row['NV3-KQ'] == 'KO'){
                                                            echo "Không đạt";
                                                        } else {
                                                            $chucmung = true;
                                                            $trungtuyen = true;
                                                            echo "<span style=\"color: blue; font-weight: bold\"> Trúng tuyển</span>";
                                                        }
                                                    }
                                                    ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="nguyenvong-item">
                                        <div class="title">
                                            <label>Nguyện vọng 4</label>
                                        </div>
                                        <div class="noidung">
                                            <?php
                                            if($row['NV4-TRUONG'] != NULL) {
                                                ?>
                                                <table>
                                                    <thead><b>Mã trường:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV4-TRUONG'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Mã ngành/nhóm ngành:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php echo $row['NV4-NGANH'];?>
                                                    </tbody>
                                                </table>
                                                <table>
                                                    <thead><b>Kết quả:</b></thead>
                                                    <tbody style="margin-left: 30px; float: left;">
                                                    <?php
                                                    if($trungtuyen == false) {
                                                        if($row['NV4-KQ'] == 'KO'){
                                                            echo "Không đạt";
                                                        } else {
                                                            $chucmung = true;
                                                            $trungtuyen = true;
                                                            echo "<span style=\"color: blue; font-weight: bold\"> Trúng tuyển</span>";
                                                        }
                                                    }
                                                    ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php 
                            if($chucmung){
                                echo "<p style=\"text-align:center; color:blue; font-weight:bold; font-size: 20px;\">Chúc mừng thí sinh!</p>
                                    <p>Thí sinh đến trường trúng tuyển làm thủ tục xác nhận nhập học (nộp Giấy chứng nhận kết quả thi bản chính) từ ngày 15/08 đến ngày 19/08/2016</p>
                                    <p>Mọi ý kiến thắc mắc xin gửi về địa chỉ Email: tsgx@hust.edu.vn hoặc gửi tin nhắn qua số điện thoại 0906 204 590 / 0906 204 591</p>
                                    ";
                            }
                            ?>
                            <div style="text-align:right; font-size: 16px; line-height: 2;"><a target="_blank" href="https://docs.google.com/spreadsheets/d/1gl9AKZRgauk2kU8aqo1XLRdHDJRwyOT3Tz7R8UVc2Fc/edit?usp=sharing">Thí sinh có thể xem toàn bộ kết quả xét tuyển tại đây!</a></div>
                            
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="wrap2">
                        <div align="center">Không tìm thấy số này. Vui lòng kiểm tra lại!</div>
                    </div>
                    <?php
                }
            }
        ?>

    </div>
</div>
	<!-- FOOTER BEGIN -->
	<div class="footer-main">
		
	</div>
	<!-- FOOTER END -->
</body>
</html>