<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detail </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="assets/viewall.css" rel="stylesheet" type="text/css" /> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<!-- hieu ung load -->
<body onLoad="init()">
<div id="loading" style="position:absolute; width:100%; text-align:center; top:250px;">
 
Loading...<br />
 
<img src="loading.gif" border=0></div>
 
<script>
 
var ld=(document.all);
 
var ns4=document.layers;
 
var ns6=document.getElementById&&!document.all;
 
var ie4=document.all;
 
if (ns4)
 
ld=document.loading;
 
else if (ns6)
 
ld=document.getElementById("loading").style;
 
else if (ie4)
 
ld=document.all.loading.style;
 
function init()
 
{
 
if(ns4){ld.visibility="hidden";}
 
else if (ns6||ie4) ld.display="none";
 
}
 
</script>
<!-- HEADER BEGIN -->
	<div class="top-main">
		<div class="wrap">
			<div class="logo">
				<h1>
				
				    <img src="assets/images/logoheader.png">
			
				</h1>
			</div>
		</div>
	</div>
	<!-- HEADER END -->
    <div style="border-top: 10px solid #f29f36;">

<div class="container.fluid">
	<div id="container" > 
  	<h1> Detail</h1>
	
	
</div>
</div>


<!-- FOOTER BEGIN -->
	<div class="footer-main">
		
	</div>
	<!-- FOOTER END -->
	
</body>

</html>
