<?php
$link = @mysql_connect ("localhost", "root", "") or
die("Khong ket noi duoc MySQL Database");
mysql_query("SET NAMES 'UTF8'");
mysql_select_db("tracuudoan", $link);




?>