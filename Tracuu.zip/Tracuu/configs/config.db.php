<?php 
	const DB_HOST = '127.0.0.1';
	const DB_USER = 'root';
	const DB_USER_PASSWD = '';
	const DB_DATABASE = 'tracuugx';

	$db = new PDO('mysql:host='.DB_HOST.';dbname='.DB_DATABASE, DB_USER, DB_USER_PASSWD, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
?>