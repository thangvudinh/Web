<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Danh sách đồ án </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="assets/viewall.css" rel="stylesheet" type="text/css" /> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<!-- hieu ung load -->
<body onLoad="init()">
<div id="loading" style="position:absolute; width:100%; text-align:center; top:250px;">
 
Loading...<br />
 
<img src="loading.gif" border=0></div>
 
<script>
 
var ld=(document.all);
 
var ns4=document.layers;
 
var ns6=document.getElementById&&!document.all;
 
var ie4=document.all;
 
if (ns4)
 
ld=document.loading;
 
else if (ns6)
 
ld=document.getElementById("loading").style;
 
else if (ie4)
 
ld=document.all.loading.style;
 
function init()
 
{
 
if(ns4){ld.visibility="hidden";}
 
else if (ns6||ie4) ld.display="none";
 
}
 
</script>
<!-- HEADER BEGIN -->
	<div class="top-main">
		<div class="wrap">
			<div class="logo">
				<h1>
				
				    <img src="assets/images/logoheader.png">
			
				</h1>
			</div>
		</div>
	</div>
	<!-- HEADER END -->
    <div style="border-top: 10px solid #f29f36;">

<div class="container.fluid">
	<div id="container" > 
  	<h1>Danh sách đồ án</h1>
  	
  <!-- xu ly select *-->
	<?php 
	require 'configs/db.php';
	$totalRows = 0;
	$stSQL ="select * from DOAN";
	$result = mysql_query($stSQL,$link);
	$totalRows = mysql_num_rows($result);
	$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
			$limit = 10;
	$total_page = ceil($totalRows / $limit);
	 if ($current_page > $total_page){
				$current_page = $total_page;
			}
			else if ($current_page < 1){
				$current_page = 1;
			}
			
	$start = ($current_page - 1) * $limit;

	$result = mysql_query("SELECT * FROM doan LIMIT $start, $limit",$link);

	?>
	<h3>Tổng số đồ án tìm thấy: <?= $totalRows ?></h3>
	<table class="table table-hover">
		<thead>
		  <tr>
			<th>Mã đồ án</th>
			<th>Đề tài</th>
			<th>Tác giả</th>
			<th>GV Hướng dẫn </th>
			<th>GV Phản biện </th>
		  </tr>
		</thead>
		<?php 
		if($totalRows>0){
	$i=0;
	while ($row = mysql_fetch_array ($result))
	{
	$i+=1;
	?>
		<tbody>
		  <tr>
			<td><?=$row["maDoAn"]?></td>
			<td><?=$row["deTai"]?></td>
			<td><?=$row["tacGia"]?></td>
			<td><?=$row["giaoVienHuongDan"]?></td>
			<td><?=$row["giaoVienPhanBien"]?></td>
			
		  </tr>
		  
		</tbody>
		
		</div>
	<?php
	 }
	}else{
	?>
	<tr valign="top">
	<td >&nbsp;</td>
	<td > <b><font face="Arial" color="#FF0000">
	Không tìm thấy thông tin !</font></b></td>
	</tr>
	<?php
	}
	?>
	  </table>
	</div>
		<center>
		<div class="pagination">
			
			<ul class="pagination">
			   <?php 
				// PH?N HI?N TH? PHÂN TRANG
				// BU?C 7: HI?N TH? PHÂN TRANG
		
				// n?u current_page > 1 và total_page > 1 m?i hi?n th? nút prev
				if ($current_page > 1 && $total_page > 1){
					echo '<li><a href="viewall.php?page='.($current_page-1).'">Prev</a></li>  ';
				}
	 
				// L?p kho?ng gi?a
				for ($i = 1; $i <= $total_page; $i++){
					// N?u là trang hi?n t?i thì hi?n th? th? span
					// ngu?c l?i hi?n th? th? a
					if ($i == $current_page){
						echo '<li><span>'.$i.'</span></li> ';
					}
					else{
						echo '<li><a href="viewall.php?page='.$i.'">'.$i.'</a></li>  ';
					}
				}
	 
				// n?u current_page < $total_page và total_page > 1 m?i hi?n th? nút prev
				if ($current_page < $total_page && $total_page > 1){
					echo '<li><a href="adminmanagement.php?page='.($current_page+1).'">Next</a></li>  ';
				}
			   ?>
			   </ul>
			</div>
		</div> 
		</center>
</div>
</div>


<!-- FOOTER BEGIN -->
	<div class="footer-main">
		
	</div>
	<!-- FOOTER END -->
	
</body>

</html>
