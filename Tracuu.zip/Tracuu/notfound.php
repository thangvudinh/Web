<?php

echo '404 NOT FOUND !!!!';
?>
<h1> Nhấn vào <a href="/"> đây</a> để trở về Trang chủ</h1>